#xelab core glbl -prj top.prj -s snapshot -debug typical -initfile=$XILINX_VIVADO/data/xsim/ip/xsim_ip.ini -L work -L xpm -L unisims_ver -L unimacro_ver
#xelab xil_oddr glbl -prj top.prj -s snapshot -debug typical -initfile=$XILINX_VIVADO/data/xsim/ip/xsim_ip.ini -L work -L xpm -L unisims_ver -L unimacro_ver
#xelab deep_sump_hyperram glbl -prj top.prj -s snapshot -debug typical -initfile=$XILINX_VIVADO/data/xsim/ip/xsim_ip.ini -L work -L xpm -L unisims_ver -L unimacro_ver
#xelab hyper_xface_pll glbl -prj top.prj -s snapshot -debug typical -initfile=$XILINX_VIVADO/data/xsim/ip/xsim_ip.ini -L work -L xpm -L unisims_ver -L unimacro_ver
#xelab hyper_xface_pll glbl -prj top.prj -s snapshot -debug typical -f vsim.opt
xelab deep_sump_fifo glbl -prj top.prj -s snapshot -debug typical -f vsim.opt
xsim snapshot -tclbatch do_files/do.tcl
cp dump.vcd ~/xfer
