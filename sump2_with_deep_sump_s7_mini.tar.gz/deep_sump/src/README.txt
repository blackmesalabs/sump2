./src contains the user source files. Intent is to keep the static IP files
  in a separate ./ip_src directory
