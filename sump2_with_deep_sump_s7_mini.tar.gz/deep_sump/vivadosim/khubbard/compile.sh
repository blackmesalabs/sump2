xvlog -prj top.prj
