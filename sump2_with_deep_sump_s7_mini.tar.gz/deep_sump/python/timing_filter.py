###########################################
# Sys ARGs
import sys;
args = sys.argv + [None]*4;
print args[0]; # one_page.py
print args[1]; # ARG0

# Extract this info from a Xilinx Vivado Report : post_route_timing_summary.rpt
# Max Delay Paths
# -------------------------------------------------------------------
# Slack (VIOLATED) :        -1.810ns  (required time - arrival time)
#   Source:                 u0_deep_sump/events_p1_reg[5]/C
#   Destination:            u0_deep_sump/rle_wd_cnt_reg[6]/CE

import sys;
import os;

def main():
  args = sys.argv + [None]*5; # args[0] is this scripts name
  report_file_name    = args[1];
  met_file_name       = args[2];
  violated_file_name  = args[3];

  # Filter the timing report and extract just the good stuff
  met_list = [];
  violated_list = [];
  timing_list = file2list( report_file_name ); # ie compile.sh
  for each_line in timing_list:
    words = " ".join(each_line.split()).split(' ') + [None] * 4;
    if ( words[0] == "Slack" ):
      slack = words[1];# (VIOLATED) or (MET)
      time  = words[3];# (VIOLATED) or (MET)
    if ( words[0] == "Source:" ):
      src = words[1];# u0_deep_sump/events_p1_reg[5]/C
    if ( words[0] == "Destination:" ):
      dst = words[1];# u0_deep_sump/rle_wd_cnt_reg[6]/CE
      timing_tuple = ( slack, src, dst );
      timing_str = "%s : %s -> %s" % timing_tuple;
      if ( slack == "(VIOLATED)" ):
        my_list = violated_list;
      if ( slack == "(MET)" ):
        my_list = met_list;
      my_list += ["%s %s" % ( slack, time )];
      my_list += ["  SRC: %s" % src];
      my_list += ["  DST: %s" % dst];


  list2file( met_file_name, met_list );
  list2file( violated_file_name, violated_list );


def file2list( file_name ):
  file_in  = open( file_name, 'r' );
  file_list = file_in.readlines();
  file_in.close();
  file_list = [ each.strip('\n') for each in file_list ];# list comprehension
  return file_list;


def list2file( file_name, my_list ):
  file_out  = open( file_name, 'w' );
  for each in my_list:
    file_out.write( each + "\n" );
  file_out.close();
  return;

try:
  if __name__=='__main__': main()
except KeyboardInterrupt:
  print 'Break!'


